//write a program to check wheather a number is negative , positive or zero

package control;

public class ques3 
{
    public static void main(String[] args)
     {
        
    }
}
