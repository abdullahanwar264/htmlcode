//Write a program to find all roots of a quadratic equation

package control;

public class ques17 
{
    public static void main(String[] args) 
    {
        
    }
}
