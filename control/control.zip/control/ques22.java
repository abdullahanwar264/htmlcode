// while purchasing certain items, a discount of 10% is offered if the quantity purchased is 
// more than 100. If quantity and price per item are input through the keyboard, write a 
// program to calculate the total expenses

package control;

public class ques22 
{
    mai
}
